<?php
namespace src\lib\php\home;

/**
 * Фасад для главной страницы
 * Пока нет идей по поводу главной страницы
 */

 class HomeFacade
 {
    public function __construct()
    {
        if (isset($_GET['home']))
            echo '<section class="container-fluid"></section>';
    }
 }
