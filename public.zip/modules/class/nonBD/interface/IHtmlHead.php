<?php
namespace class\nonBD\interface;

interface IHtmlHead
{
    
}
