<?php
namespace src\libraries;

class Footer
{
    public function __toString()
    {
        return "
        <footer>
        </footer>
        </body>
        </html>
        ";
    }
}
