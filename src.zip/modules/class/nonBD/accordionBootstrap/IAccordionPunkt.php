<?php
namespace class\nonBD\accordionBootstrap;

abstract class IAccordionPunkt
{
    abstract public function returnPunkt();
    
}
