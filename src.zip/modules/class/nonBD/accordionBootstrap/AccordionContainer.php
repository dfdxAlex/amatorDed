<?php
namespace class\nonBD\accordionBootstrap;
/**
 * Главный класс, который принимает в себя все элементы
 * аккордиона и выводит их
 */

class AccordionContainer
{
    /**
     * возможные варианты accordion или accordion accordion-flush
     * Взято из примера бутстрапа 5
     */
    private $class = 'accordion';
    /**
     * возможные варианты accordionExample, accordionFlushExample,
     * accordionPanelsStayOpenExample.
     * Взято из примера бутстрапа 5
     */
    private $id = 'accordionExample';


}
