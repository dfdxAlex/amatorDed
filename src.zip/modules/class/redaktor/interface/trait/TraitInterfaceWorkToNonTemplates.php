<?php
namespace class\redaktor\interface\trait;

trait TraitInterfaceWorkToNonTemplates
{
    
}
