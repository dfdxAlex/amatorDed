<?php
namespace src\lib\php;

class Futter
{
    public function __construct()
    {
        echo '</body></html>';
    }
}


