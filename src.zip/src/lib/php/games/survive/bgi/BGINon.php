<?php
namespace src\lib\php\games\survive\bgi;

/**
 * Класс возвращает имя пустого стилевого класса,
 */

class BGINon implements IBGI
{
    public function returnBGI()
    {
        return "non";
    }
}
