<?php
namespace src\lib\php\games\survive\state\bag;

/**
 * интерфейс для класса содержимого сумки
 */

interface IBag
{
    
}
